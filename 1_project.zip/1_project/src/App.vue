<template>
  <input type="text" v-model="userName" placeholder="Имя">
  <input type="password" v-model="userPass" placeholder="Пароль">
  <input type="email" v-model="userEmail" placeholder="E-mail">

  <p clsasName="error">{{ error }}</p>
  <button @click="sendData()">Отправить</button>

  <div v-if="users.length == 0">
    У нас нет пользователей
  </div>
  <div v-else-if="users.length == 1">
    Появился 1 пользователь
  </div>
  <div v-else="users.length > 1">
    Больше пользователей
  </div>

  <User v-for="(i, index) in users" :key="index" :user="i" :index="index" :deleteData="deleteData" />
</template>

<style scoped>
  input {
    display: block;
    margin-bottom: 10px;
    padding: 8px;
    width: 100%;
    max-width: 300px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
  }

  button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
  }

  button:hover {
    background-color: #45a049;
  }

  .error {
    color: red;
    font-weight: bold;
    margin-bottom: 10px;
  }

  .user {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    padding: 10px;
    margin-top: 10px;
    border-radius: 5px;
  }

  h3 {
    margin: 0 0 5px 0;
  }

  p {
    margin: 0;
    font-size: 14px;
  }
</style>

<script>
  import User from './components/User.vue'
  export default{
    components:{
      User
    },
    data(){
      return{
        users: [],
        error: '',
        userName: '',
        userPass: '',
        userEmail: ''
      }
    },
    methods: {
      sendData(){
        if(this.userName == '') {
          this.error="Имя не введено";
          return;
        }
        if(this.userPass == '') {
          this.error="Пароль не введен";
          return;
        }
        if(this.userEmail == '') {
          this.error="Нет Emailа";
          return;
        }
        this.error = ''
        this.users.push({
          name: this.userName,
          pass: this.userPass,
          email: this.userEmail
        })
      },
      deleteData(index) {
        this.users.splice(index, 1)
      }
    }
  }
</script>
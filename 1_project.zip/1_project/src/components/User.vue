<template>
    <div className="user">
        <button class="delete-button" @click="deleteData(index)">Удалить</button>
        <h3>{{ user.name }}</h3>
        <p>{{ user.email }} - <b>{{ user.pass }}</b></p>
    </div>
</template>

<script>
    export default{
        props:{
            user: {
                type: Object,
                required: true
            },
            index:{
                type: Number,
                required: true
            },
            deleteData:{
                type: Function,
                reqiured: true
            }
        }

    }
</script>

<style>
.user {
    position: relative; /* Это позволит использовать абсолютное позиционирование внутри элемента .user */
    padding: 10px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
}

.delete-button {
    position: absolute;
    top: 5px;
    right: 5px;
    background-color: red;
    color: white;
    border: none;
    border-radius: 3px;
    padding: 5px 10px;
    cursor: pointer;
}

.delete-button:hover {
    background-color: darkred;
}
</style>